------------------------------------------------------------------------
Nuvoton Technology Corporation - Confidential
NPCM750 (Poleg) UART Update Tool Package Release Letter
Copyright (c) 2015 Nuvoton Technology Corporation. All Rights Reserved.
------------------------------------------------------------------------

By downloading, installing, copying, or otherwise using the Nuvoton 
NPCM750 UART Update Tool, you accept the terms in EULA.txt license agreement

NPCM750 UART Update Tool package for the Nuvoton NPCM750 Chip
Release Letter
Version:  1.7.1
Date:     Novemeber 2015


PACKAGE CONTENTS
----------------
- UartUpdateTool.exe                - The UART Update Tool Windows application.
- uut.exe                           - The UART Update Tool DOS application.
- UART_Update_Tool_User_Guide.pdf   - A short User Manual.
- RelLetter.txt                     - This Release Letter.
- EULA.txt                          - End User License Agreement.


DESCRIPTION
-----------
This package contains the Nuvoton UART Update Tool for the NPCM750.
This package is released in Beta quality.
The UART Update Tool meets the requirements as specified in NPCM750 
Arch-Spec Revision 0.70.

The UART Update Tool enables doing the following operations via NPCM750 Serial Port 2:
1. Write to Memory or Flash.
2. Read from Memory or Flash.
3. Execute code from a specific address.
4. Erase the Flash.
5. Print Flash information.
6. Unlock Flash.


REQUIREMENTS
------------
Operating System:    
- Windows 7 / XP / Vista
- DOS.

Hardware:
- A platform containing a Nuvoton NPCM750 device with Serial Port 2 connector.


INSTALLATION PROCEDURE 
----------------------
Execute UartUpdateTool.exe application according to the instructions specified 
in the User Manual.


ENHANCEMENTS
------------
- None


FIXED ISSUES
------------
- Allow erase Flash device operation on all chips.


KNOWN ISSUES
------------
- Application assumes each Flash device starts on a 16MB boundary.
- Application can not program beyond a single device flash.


HISTORY
-------
UART Update Tool ver 1.7.1 (1.11.2015)
======================================
1. Print the "out of" parameter while burn in is in progress. 

1.7.0 (08.03.2015)
==================
1. Support comport 1-256
2. Fix operation 6 (EXECUTE and EXIT)
3. Support automatic production for Windows

1.6.3 (30.12.2014)
==================
1. Poleg support
2. Default is the latest chip (Poleg).
3. Yarkon Z1 bypass is according to chip selection at run time.
4. Windows automatic production

1.6.2 (10.01.2010)
==================
1. Bug fix - Allow erase Flash device operation on all chips.

1.6.1 (01.01.2010)
==================
1. Change "-v" to "-version".
2. Moved dos_makefile to build dir.
3. Fixed a bug in data printing which caused to infinite loop.
4. Fixed a bug in ComPortReadBin() for DOS version that caused stack overflow.
5. Fixed operation numbers printing bug.
6. Fixed memory reading bug in DOS.
7. Added "tests" directory with sanity-

1.6.0 (24.12.2009)
==================
1. Added support for DOS (with Watcom compiler).
2. Added -v option that prints the tool version.

1.5.2 (13.12.2009)
==================
1. Bug fix in OPR_SendCmds() - Allow ALL bytes to arrive during READ operation.
2. Inform user on chip-specific operations.

1.5.1 (10.11.2009)
==================
1. Bug fix in OPR_CheckSync() - Allow ROM-Code enough time to send a SYNC 
   response.

ver 1.5.0 (10.11.2009)
======================
1. Replace print messages (DISPLAY_MSG) with color messages (displayColorMsg).

ver 1.4.2 (09.11.2009)
======================
1. Add color printing capabilities.

ver 1.4.1 (09.11.2009)
======================
1. Add ScanBaudRate feature.
2. Fix synchronization issue.
3. Make the application to return different exit codes on failure.
4. Add ReadStsMessage function for BMC Configuration Tool.

ver 1.4.0 (29.9.2009)
======================
1. Fix a bug during Host/Core synchronization phase.
2. Allow applying data to be written via console (instead of file).

ver 1.3.5 (21.9.2009)
=====================
1. Enhance command-line parsing.
2. Enhance Read/Write progress display.
3. Warn and receive user agreement before erasing a flash device.

ver 1.3.2 (23.8.2009)
=====================
1. Increase Flash-erase delay to 120 seconds.
2. Bug fix - retrieve ROM-Code response prior to waiting till device is ready.
3. Perform _Z1_BYPASS_ in Yarkon Z1 chip only (not applicable for Hermon).

ver 1.3.1 (5.8.2009)
====================
1. Finalize SW standard definition component inclusion (defs.h).
2. Include MSVC system header files.

ver 1.3.0 (3.8.2009)
====================
1. Continue code porting to use SW definition file and SW coding standards.
2. Multiple chip support using a single application (-chip switch):
   Default is the latest chip (Yarkon).
3. Arrange all chip-specific info under 'chip' module (header and source file).
4. Implement a function to build an SPI Flash command buffer, 
   based on FIU User Mode Access (UMA).

ver 1.2.0 (2.8.2009)
====================
1. Bug fix: CHIP definition was wrongly inverted to define chip base addresses.
2. Bug fix: OPR_WriteMem, handle cases where write size is the exact size 
   of the file (due to feof() behavior).
3. Bug fix: In Flash Write/Erase operations, wait till Flash device is ready before 
   performing additional operations.
3. Perform a synchronization check with ROM-Code before sending any commands.
4. Support two execution operations:
   a. Execute and Exit - execute a non-return code and exit UART application.
   b. Execute and Continue - execute a returnable code, UART application continues.
5. Support Flash Erase commands (Bulk and Sector) by direct UMA register configuration.
6. Print to file/screen (-console switch):
   '-console' will print read data to console, otherwise (default behavior) 
   print to output file.
8. Silent mode (-silent switch).
   Use DISPLAY_MSG() to suppress printing in silent mode.
9. Add 'main.h' as a common project definition file.
10.Use Time-out mechanism on relevant loops to prevent application from being hanging.
11. Perform a page boundary check on Flash programming command (not exceeding page's 
    size in a single command).
12. Determine Baud Rate using a parameter (-baudrate switch):
    a. Using 115200 as a default.
    b. Parameter is applicable only when parameters are specified (that is, 
       default is used when in Shell invocation mode).
13. Yarkon SW #issue 278:
    Bypass the issue by removing extra characters (ROM-Code puts additional '\r' 
    character per each '\n').
14. Add parameter checking functionality.

ver 1.1.0 (15.7.2009)
=====================
1. Port the code to conform to the SW coding standards.
2. Support parameter passing from command line.

ver 1.0.5 (12.7.2009)
=====================
1. Rearrange the code in a modular fashion (functionality remains as-is).
2. Add tool version printing to console.

ver 1.0.4 (13.7.2008)
=====================
1. "Write to Memory/Flash" option was changed for  writing files with not limited size.
2. "Read from Memory/Flash" option was changed for dumping data to binary file. 
   (previous it was printed to console)
   
ver 1.0.3 (21.4.2008)
=====================
1. When application is opened its print ID and Status Register four first flash chips.
2. Added three new options in menu : Print Flash ID, Print Flash Status Register,
   Unlock Flash.
   
ver 1.0.2 (6.4.2008)
====================
1. Changed MSVC solution properties for compiling with static libraries.
2. Changed ReadMe.txt file

ver 1.0.1 (6.4.2008)
====================
1. Added parameter (COM port number) for command line running.
2. Added new option "Execute From Address".

ver 1.0.0 (1.4.2008)
====================
1. First release.


-----------------------------------------------------------
For contact information see "Contact Us" at www.nuvoton.com
-----------------------------------------------------------
