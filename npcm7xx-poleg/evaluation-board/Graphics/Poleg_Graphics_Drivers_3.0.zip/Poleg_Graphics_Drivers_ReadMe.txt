------------------------------------------------------------------------
Nuvoton Technology Corporation
Poleg Graphics Drivers
Release Letter
Copyright (c) 2017 Nuvoton Technology Corporation. All Rights Reserved.
------------------------------------------------------------------------

Poleg Graphics Drivers Release Letter
Version:  3.0
Date:     April 2017


PACKAGE CONTENTS
----------------
This package contains the following files:

---------------------------------------------------+-------------+-------------------------------------------------
                     Name                          |   Version   |                  Description
---------------------------------------------------+-------------+-------------------------------------------------
899-40wg.zip                                       | 899-40WG    | Matrox G200eW VGA BIOS
                                                   |             | (see "BIOS Release Notes.txt" for more details)
---------------------------------------------------+-------------+-------------------------------------------------
g2ew_uefi_v2_5_signed.zip                          | 2.5         | Matrox G200eW UEFI driver
                                                   |             | (see "release notes.txt" for more details)
---------------------------------------------------+-------------+-------------------------------------------------
xorg-x11-drv-mga-1.6.3-5.el6_1.i686.rpm            | 1.6.3-5     | Linux Red Hat 6.6 Graphics driver
xorg-x11-drv-mga-1.6.3-5.el6_1.x86_64.rpm          |             |
---------------------------------------------------+-------------+-------------------------------------------------
kernel-3.10.0-229.1.2.el7_1.x86_64.rpm             | 3.10.0      | Linux Red Hat 7.1 Graphics driver
---------------------------------------------------+-------------+-------------------------------------------------
xorg-x11-driver-video-7.4.0.1-0.81.27_1.i586.rpm   | 7.4.0.1     | Linux SLES 11.3 Graphics driver
xorg-x11-driver-video-7.4.0.1-0.81.27_1.x86_64.rpm |             |
---------------------------------------------------+-------------+-------------------------------------------------
xf86-video-mga-1.6.3-3.13_1.x86_64.rpm             | 1.6.3       | Linux SLES 12 Graphics driver
---------------------------------------------------+-------------+-------------------------------------------------
g2w_wddm_v4_03_03_007_whql.zip                     | 4.03.03.007 | Windows WDDM driver
                                                   |             | (see "MxG2wDO_ReleaseNotes.txt" for more details)
---------------------------------------------------+-------------+-------------------------------------------------
g200ew_v1_04_007-whql.zip                          | 1.04.007    | Windows XDDM driver
                                                   |             | (see "G200eWReleaseNotes.txt" for more details)
---------------------------------------------------+-------------+-------------------------------------------------
Poleg_Graphics_Drivers_ReadMe.txt                  | 3.0         | This Release Letter
---------------------------------------------------+-------------+-------------------------------------------------


DESCRIPTION
-----------
This is the full Poleg Graphics drivers package.

Windows WDDM driver supports the following O/S:
  1. WS2012
  2. WS2012R2
  3. WS2016 (in the future)
* WDDM driver - note that the current driver has been certified for WS2012 and WS2012R2.

Windows XDDM driver supports the following O/S:
  1. WS2003R2
  2. WS2008
  3. WS2008R2
* XDDM driver - This driver is supported in WS2003, WS2003x64, WS2008, WS2008x64 and WS2008R2x64. 
                This driver includes dual support for the device ids 0532 and 0536.


REQUIREMENTS
------------
Hardware:
- Nuvoton Poleg Chip.


INSTALLATION PROCEDURE
----------------------
Please refer to the drivers' readme files for more information.


ENHANCEMENTS
------------
Added a registry switch User.EnableWidescreenNoEDID to enable widescreen modes even when no monitor is attached.
Added a registry switch to un-hide modes that aren't supported by the monitor.
If an user wants to enable hi-res widescreen mode, he need to uncheck the box in the monitor tab.


FIXED ISSUES
------------
Resolved hot plug issues.


KNOWN ISSUES
------------
None.


HISTORY
-------

Ver 2.0
-------
	ENHANCEMENTS
	------------
	- Added certified Windows WDDM/XDDM drivers.
	- Added MtxSetup.ini file to customize the WDDM driver.

Ver 1.0
-------
	ENHANCEMENTS
	------------
	Matrox G200eW UEFI driver:
	--------------------------
	- Added support for new device id 0536.
	- Added support for new modes 1280x720 and 1920x1080.

	FIXED ISSUES
	------------
	Matrox G200eW VGA BIOS:
	-----------------------
	- Brought back 1600x1200x32bpp.

	Matrox Windows WDDM driver:
	---------------------------
	- Added missing modes 280x720x60 Hz and 1920x1080x60Hz to supported mode list.
	- Fixed intermittent hardware cursor corruption that was occurring at the top edge of the screen.

	Matrox Windows XDDM driver:
	---------------------------
	- Fixed User.SetHiPriThreshold registry key.
	  It now properly modifies the hipri threshold register.
	  It is not visible in the registry by default.
	- The default value for the hipri threshold register is 0x10.

-----------------------------------------------------------
For contact information see "Contact Us" at www.nuvoton.com
-----------------------------------------------------------
